from django.db import models

# Create your models here.

class Cidade (models.Model):
    nome = models.CharField(max_length=50)
    UF = models.CharField(max_length=30)
    
    def __str__(self):
        return f'{self.nome}{self.UF}' 

class Autor (models.Model):
    nome = models.CharField(max_length=50)
    site = models.CharField(max_length=100)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.nome}{self.site}{self.cidade}'
    
class Editora (models.Model):
    nome = models.CharField(max_length=50)
    site = models.CharField(max_length=100)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.nome}{self.site}{self.cidade}'
    
class Categoria (models.Model):
    nome = models.CharField(max_length=50)

    def __str__(self):
        return self.nome

class Livro (models.Model):
    nome = models.CharField(max_length=50)
    autor = models.ForeignKey(Autor, on_delete=models.CASCADE)
    editora = models.ForeignKey(Editora, on_delete=models.CASCADE)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)
    preco = models.PositiveIntegerField()
    data_publicacao = models.DateTimeField(auto_now = True)

    def __str__(self):
        return f'{self.nome}{self.autor}{self.editora}{self.categoria}{self.preco}{self.data_publicacao}'
 

class Leitores (models.Model):
    nome = models.CharField(max_length=50)
    email = models.CharField(max_length=100)
    CPF = models.CharField(max_length=50)

    def __str__(self):
        return f'{self.nome}{self.email}{self.CPF}'        

class Emprestimo (models.Model):
    data_emprestimo = models.DateTimeField(auto_now = True)
    livro = models.ForeignKey(Livro, on_delete=models.CASCADE)
    leitor = models.ForeignKey(Leitores, on_delete=models.CASCADE)
    data_devolucao = models.DateTimeField(auto_now = True)
      
    def __str__(self):
        return f'{self.data_emprestimo}{self.livro}{self.leitor}{self.data_devolucao}'

  