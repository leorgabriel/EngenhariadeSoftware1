from django.contrib import admin
from app.models import *

# Register your models here.


admin.site.register(Genero)
admin.site.register(Continente)
admin.site.register(Pais)
admin.site.register(Direator)
admin.site.register(Filme)
admin.site.register(Serie)
admin.site.register(Episodio)
admin.site.register(Temporada)
admin.site.register(EP_Serie)
admin.site.register(Filme_Ator)