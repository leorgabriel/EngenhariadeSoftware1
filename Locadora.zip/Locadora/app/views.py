from django.shortcuts import render
from . models import*

# Create your views here.

def consulta_filme(request):
    consulta_filmes = {
        'consulta_filmes': Filme.objects.all()
        }
    return render(request, 'consulta/consulta_filme.html', consulta_filmes)

def consulta_serie(request):
    consulta_series = {
        'consulta_series': Serie.objects.all()
        }
    return render(request, 'consulta/consulta_serie.html', consulta_series)

def consulta_direator(request):
    consulta_direatores = {
        'consulta_direatores': Direator.objects.all()
        }
    return render(request, 'consulta/consulta_direator.html', consulta_direatores)
