from django.db import models

# Create your models here.

class Genero (models.Model):    
    nome_genero = models.CharField(max_length=60)    

    def __str__(self):
        return self.nome_genero
    
class Continente (models.Model):
    nome_continente = models.CharField(max_length=20)

    def __str__(self):
        return self.nome_continente
    
class Pais (models.Model):
    nome_pais = models.CharField(max_length=50)
    continente_pais = models.ForeignKey(Continente, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.nome_pais}{self.continente_pais}'
    
class Direator (models.Model):
    nome_direator = models.CharField(max_length=60)
    site_direator = models.CharField(max_length=60) 
    insta_direator = models.CharField(max_length=60)
    tt_direator = models.CharField(max_length=60)
    nacionalidade_direator = models.ForeignKey(Pais, on_delete=models.CASCADE)   
      
    def __str__(self):
        return f'{self.nome_direator}{self.site_direator}{self.insta_direator}{self.tt_direator}{self.nacionalidade_direator}'
    

class Filme (models.Model):
    nome_filme = models.CharField(max_length=60)
    duracao_filme = models.DecimalField(max_digits=4, decimal_places=2)
    sinopse_filme = models.TextField(max_length=250)
    site_filme = models.CharField(max_length=60)
    data_lancamento_filme = models.DateField(auto_now=False)
    nota_avaliacao_filme = models.DecimalField(max_digits=4, decimal_places=2)
    genero_filme = models.ForeignKey(Genero, on_delete=models.CASCADE)
    pais_filme = models.ForeignKey(Pais, on_delete=models.CASCADE)
    diretor_filme = models.ForeignKey(Direator, on_delete=models.CASCADE)
          
    def __str__(self):
        return f'{self.nome_filme}{self.duracao_filme}{self.sinopse_filme}{self.site_filme}{self.data_lancamento_filme}{self.nota_avaliacao_filme}{self.genero_filme}{self.pais_filme}{self.diretor_filme}'

class Serie (models.Model):
    nome_serie = models.CharField(max_length=60)
    duracao_serie = models.DecimalField(max_digits=4, decimal_places=2)
    sinopse_serie = models.TextField(max_length=250)
    site_serie = models.CharField(max_length=60)
    data_lancamento_serie = models.DateField(auto_now=False)
    nota_avaliacao_serie = models.DecimalField(max_digits=4, decimal_places=2)
    genero_serie = models.ForeignKey(Genero, on_delete=models.CASCADE)
    pais_serie = models.ForeignKey(Pais, on_delete=models.CASCADE)
    diretor_serie = models.ForeignKey(Direator, on_delete=models.CASCADE)
    
    def __str__(self):
        return f'{self.nome_serie}{self.duracao_serie}{self.sinopse_serie}{self.site_serie}{self.data_lancamento_serie}{self.nota_avaliacao_serie}{self.genero_serie}{self.pais_serie}{self.diretor_serie}' 
    
class Episodio (models.Model):
    nome_episodio = models.CharField(max_length=50)
    duracao_episodio = models.DecimalField(max_digits=4, decimal_places=2)
    data_disp_episodio = models.DateField(auto_now=False)
    
    def __str__(self):
        return f'{self.nome_episodio}{self.duracao_episodio}{self.data_disp_episodio}'
    

class Temporada (models.Model):
    num_temporada = models.CharField(max_length=50)
    
    def __str__(self):
        return self.num_temporada       


class EP_Serie (models.Model):
    nome = models.ForeignKey(Serie, on_delete=models.CASCADE)
    temporada = models.ForeignKey(Temporada, on_delete=models.CASCADE) 
    episodio = models.ForeignKey(Episodio, on_delete=models.CASCADE)
      
    def __str__(self):
        return f'{self.nome}{self.temporada}{self.episodio}'

class Filme_Ator (models.Model):    
    filme = models.ForeignKey(Filme, on_delete=models.CASCADE) 
    ator = models.ForeignKey(Direator, on_delete=models.CASCADE)
      
    def __str__(self):
        return f'{self.filme}{self.ator}'