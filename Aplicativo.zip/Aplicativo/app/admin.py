from django.contrib import admin
from app.models import *

# Register your models here.

admin.site.register(Meta)
admin.site.register(Pessoa)
admin.site.register(Alimento)
admin.site.register(RegistroAlimento)
admin.site.register(Noticia)
admin.site.register(Receita)
