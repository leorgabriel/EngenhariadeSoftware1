from django.db import models

# Create your models here.

class Meta(models.Model):
    caloria = models.DecimalField(max_length=6)
    prazo = models.IntegerField()

    def __str__(self):
        return f'{self.caloria}{self.prazo}'
    

class Pessoa(models.Model):
    nome = models.CharField(max_length=100)
    idade = models.IntegerField()
    sexo = models.CharField(max_length=10)
    peso = models.DecimalField(max_length=4)
    altura = models.DecimalField(max_length=4)
    meta_definida = models.ForeignKey(Meta, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.nome}{self.idade}{self.sexo}{self.peso}{self.altura}'
    
    
class Alimento(models.Model):
    nome = models.CharField(max_length=60)

    def __str__(self):
        return self.nome
    
class RegistroAlimento(models.Model):
    data = models.DateField(auto_now=False)
    nome = models.ForeignKey(Alimento, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.data}{self.nome}'
    
class Noticia(models.Model):
    titulo = models.CharField(max_length=60)
    texto = models.CharField(max_length=500)
    data = models.DateField(auto_now=False)

    def __str__(self):
        return f'{self.titulo}{self.texto}{self.data}'
    
class Receita(models.Model):
    nome = models.CharField(max_length=60)
    ingrediente = models.CharField(max_length=200)
    descricao = models.CharField(max_length=500)

    def __str__(self):
        return f'{self.nome}{self.ingrediente}{self.descricao}'
